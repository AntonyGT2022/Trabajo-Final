/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FabricGestion; 

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author randomç
 */
public class FabricSend {
    protected String usuario;
    protected String nombre;
    protected String apellido;
    protected String telefono;
    protected String correo;
    protected String contraseña;
    protected String verificontra;

    public FabricSend(String Usertxt, String Nombretxt, String Apellidotxt, String telefonotxt, String Correotxt, String jPasswordField1, String VerificarContraseña) {
        this.usuario = Usertxt;
        this.nombre = Nombretxt;
        this.apellido = Apellidotxt;
        this.telefono = telefonotxt;
        this.correo = Correotxt;
        this.contraseña = jPasswordField1;
        this.verificontra = VerificarContraseña;
    }

    public FabricSend(String usu, String contra) {
     this.usuario = usu;
        this.contraseña = contra;  
    }
  
    public void returndat(){
        if(nombre == null&& apellido == null && telefono == null && correo == null && verificontra == null && contraseña != null && usuario != null ){
            GestLogn login = new GestLogn(usuario,contraseña);
            login.gestlogin();
        }
        else {
            GestReg registro = new GestReg(usuario, nombre, apellido,telefono,correo,contraseña,verificontra);
            try {
                registro.usu();
            } catch (SQLException ex) {
                Logger.getLogger(FabricSend.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}

