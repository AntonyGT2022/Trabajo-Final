/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FabricGestion;


import Forms.Usu_producto;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author randomç
 */
public class GestLogn extends Gestion {

    GestLogn(String usuario, String contraseña) {
        this.usuario = usuario;
        this.contraseña = contraseña;
    }
   
    public void gestlogin(){
  try {
            con.sttment.execute(query);
            con.rs = con.sttment.executeQuery(query);

            if (usuario.isEmpty() || contraseña.isEmpty()) {

                JOptionPane.showMessageDialog(null, "Debe llenar ambos campos correctamente", "Resultado", JOptionPane.INFORMATION_MESSAGE);

           } else {

          while (con.rs.next()) {
              if (con.rs.getString("contraseña").equals(contraseña )&& con.rs.getString("usuario").equals(usuario) ) {

                  Usu_producto usua = new Usu_producto();
                  usua.setVisible(true);

              } 

          }
      }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    } 
    }

