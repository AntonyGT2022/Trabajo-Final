/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FabricGestion;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author randomç
 */
public class GestReg extends Gestion {

    GestReg(String usuario, String nombre, String apellido, String telefono, String correo, String contraseña, String verificontra) {
     this.usuario = usuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.correo = correo;
        this.contraseña = contraseña;
        this.verificontra = verificontra;  
    }

    public void usu() throws SQLException {
        try {
            String query = "insert into usuario (usuario,nombre,apellido,telefono,correo,contraseña) values (?,?,?,?,?,?)";

            PreparedStatement stateme = conec.prepareStatement(query);
            String[] vacio = {usuario, nombre, apellido, telefono, correo, contraseña};

            if (contraseña.equals(verificontra)) {

                for (int i = 0; i < vacio.length; i++) {
                    stateme.setString(i + 1, vacio[i]);
                }
                stateme.execute();

            } else {
                    JOptionPane.showMessageDialog(null, "Contraseñas distintas", "Resultado", JOptionPane.INFORMATION_MESSAGE);
                }

        } catch (SQLException ex) {
            Logger.getLogger(Gestion.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
