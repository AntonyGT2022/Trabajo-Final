/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FabricGestion;

import java.sql.Connection;
import consa.Sql;

/**
 *
 * @author randomç
 */
public class Gestion {
    Sql con = new Sql();
    Connection conec = con.getConexion();
   
    protected String usuario;
    protected String nombre;
    protected String apellido;
    protected String telefono;
    protected String correo;
    protected String contraseña;
    protected String verificontra;
 // String query = "SELECT * from usuario where usuario ='" + usuario + "'" + "and contraseña ='" + contraseña + "'";
  String query = "Select usuario, contraseña from usuario";
    }




