package consa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Sql {
    public Connection con;
    public Statement sttment;
    public ResultSet rs;
	public Connection getConexion() {
		
	
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
                                con = (Connection) DriverManager.getConnection( "jdbc:mysql://localhost:3306/usuarios","root","");
                                System.err.println("Exito");
			  
                                sttment = con.createStatement(); 
                                
			} catch (SQLException e) {
				System.out.println("Error de sql");
			}
                         catch (ClassNotFoundException e) {
                            System.out.println("Clase no encontrada");
                        }
			return con;
        }
}
